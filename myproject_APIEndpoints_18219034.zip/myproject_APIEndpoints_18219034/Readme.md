To run the virtual environment, run 
    bash env.sh

to run the server, run
    bash run.sh

    open http://127.0.0.1:8000/ to look at the data modified
    open http://127.0.0.1:8000/docs to look at the documentation

to quit from the virtual environment, type and enter:
    exit

to quit from the server, click
    control+c (in macOS)