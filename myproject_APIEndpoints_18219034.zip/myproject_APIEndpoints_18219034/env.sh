pipenv install
pipenv shell